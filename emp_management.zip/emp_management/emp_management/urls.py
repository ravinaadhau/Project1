"""
URL configuration for emp_management project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app1 import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home,name="home"),
    path('add_emp',views.add_emp,name="add_emp"),
    path('del_emp/<int:eid>',views.del_emp,name="del_emp"),
    path('updt_emp/<int:eid>',views.updt_emp,name="updt_emp"),
    path('view_emp/<int:eid>',views.view_emp,name="view_emp"),
    path('search_emp',views.search_emp,name="search_emp"),
    path('search_male',views.search_male,name="search_male"),
    path('search_female',views.search_female,name="search_female"),
    path('asc_salary',views.asc_salary,name="asc_salary"),
    path('desc_salary',views.desc_salary,name="desc_salary"),
    path('search_dept',views.search_dept,name="search_dept"),
]


