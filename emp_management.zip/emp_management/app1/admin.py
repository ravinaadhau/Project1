from django.contrib import admin
from.models import Employee,Department

# Register your models here.
class DepartmentAdmin(admin.ModelAdmin):
    list_display=["id","name"]

class EmployeeAdmin(admin.ModelAdmin):
    list_display=["id","name","email","gender","doj","salary","city","dept"]


admin.site.register(Department,DepartmentAdmin)
admin.site.register(Employee,EmployeeAdmin)