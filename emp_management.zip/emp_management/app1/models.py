from django.db import models

# Create your models here.
class Department(models.Model):
     name= models.CharField(max_length=50)

     def __str__(self):
          return self.name
     
class Employee(models.Model):
    gen = (
         ('Male','male'),
         ('Female','female'),
         ('Others','others')
    )
    name = models.CharField(max_length=50)
    email=models.EmailField(max_length=254,unique=True)
    doj = models.DateField(auto_now=False, auto_now_add=False)
    salary = models.DecimalField(max_digits=7,decimal_places=2)
    city = models.CharField(max_length=50)
    gender = models.CharField(max_length=50 ,choices=gen)
    dept= models.ForeignKey(Department,on_delete=models.CASCADE)
    