from django.shortcuts import render , redirect
from .models import Employee,Department

# Create your views here.
def home(request):
    employees = Employee.objects.all()
    print(employees)
    context={'employees':employees}
    return render(request,"index.html",context)

def add_emp(request):
    try:
        departments = Department.objects.all()
        if request.method == "POST":
            name = request.POST['name']
            email = request.POST['email']
            doj = request.POST['doj']
            city = request.POST['city']
            salary = request.POST['salary']
            gender = request.POST['gridRadios']
            dept = request.POST['dept']
            department = Department.objects.get(name = dept)


            emp = Employee.objects.create(name=name,email=email,doj=doj,city=city,salary=salary,gender=gender,dept=department)
            emp.save()
            return redirect('home')
    
    except:
        error="Email already exists"
        context={'departments':departments,'error':error}
        return render(request,"addEmp.html",context)

    context ={'departments':departments}
    return render(request,"addEmp.html",context)

def del_emp(request,eid):
    emp=Employee.objects.get(id=eid)
    emp.delete()
    return redirect('home')

def updt_emp(request,eid):
   emp=Employee.objects.get(id=eid)
   departments = Department.objects.all()
   if request.method =='POST':
        name = request.POST['name']
        email = request.POST['email']
        doj = request.POST['doj']
        city = request.POST['city']
        salary = request.POST['salary']
        gender = request.POST['gridRadios']
        dept = request.POST['dept']
        department = Department.objects.get(name = dept)
        emp = Employee(id=eid,name=name,email=email,doj=doj,city=city,salary=salary,gender=gender,dept=department)
        emp.save()
        return redirect('home')
        
   context={'employee':emp,'departments':departments}
   return render(request,"updtEmp.html",context)

def view_emp(request,eid):
    emp = Employee.objects.get(id=eid)
    context={'employee':emp}
    return render(request,"view.html",context)

def search_emp(request):
    if request.method == "POST":
        email = request.POST['search']
        emp = Employee.objects.filter(email__iexact=email)
        if emp.exists():
           context= {'employees':emp}
        else:
           context = {'error':"No Record Found"}
           
        return render(request,"index.html",context)
    
def search_male(request):
    emp = Employee.objects.filter(gender__iexact="male")
    context={'employees':emp}
    return render(request,"index.html",context)

def search_female(request):
    emp = Employee.objects.filter(gender__iexact="female")
    context={'employees':emp}
    return render(request,"index.html",context)

def asc_salary(request):
    emp = Employee.objects.all().order_by('salary')
    context={'employees':emp}
    return render(request,"index.html",context)

def desc_salary(request):
    emp = Employee.objects.all().order_by('-salary')
    context={'employees':emp}
    return render(request,"index.html",context)

def search_dept(request):
    dept= request.GET.get('dpt')
    department= Department.objects.get(name=dept)
    emp=Employee.objects.filter(dept=department)
    
    context={'employees':emp}
    return render(request,"index.html",context)